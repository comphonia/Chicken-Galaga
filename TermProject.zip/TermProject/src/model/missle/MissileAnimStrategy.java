package model.missle;

public interface MissileAnimStrategy {
    void animate();
}
