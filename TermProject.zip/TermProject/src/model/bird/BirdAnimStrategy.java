package model.bird;

public interface BirdAnimStrategy {
    void animate();
}
