package controller.observer;

public interface Observer {
    void eventReceived();
}
