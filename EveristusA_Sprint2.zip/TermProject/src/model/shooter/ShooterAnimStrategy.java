package model.shooter;

public interface ShooterAnimStrategy {
    void animate();
}
