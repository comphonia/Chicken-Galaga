package model.dropping;

public interface DroppingAnimStrategy {
    void animate();
}
